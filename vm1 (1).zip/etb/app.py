from flask import Flask, request, render_template, redirect, url_for, flash
import mongomock
from bson.objectid import ObjectId
from werkzeug.exceptions import NotFound
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, TextAreaField, URLField, SubmitField
from wtforms.validators import DataRequired, URL, NumberRange

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a secure key in production

# Fake MongoDB configuration using mongomock
client = mongomock.MongoClient()
db = client.virtual_museum
ARTWORKS_COLLECTION = db.artworks

# Ensure text index for search functionality
ARTWORKS_COLLECTION.create_index([('title', 'text'), ('artist', 'text'), ('description', 'text')])

# Seed initial data
def seed_data():
    artworks = [
        {
            "title": "Starry Night",
            "artist": "Vincent van Gogh",
            "year": 1889,
            "medium": "Oil on canvas",
            "image_url": "https://i.etsystatic.com/17242443/r/il/5ee139/2280354586/il_fullxfull.2280354586_ddec.jpg",
            "description": "A famous painting by Vincent van Gogh.",
            "feedback": []
        },
        {
            "title": "Mona Lisa",
            "artist": "Leonardo da Vinci",
            "year": 1503,
            "medium": "Oil on wood",
            "image_url": "https://upload.wikimedia.org/wikipedia/commons/a/a5/Mona_Lisa_-_the_Louvre.jpg",
            "description": "A portrait painting by the Italian artist Leonardo da Vinci.",
            "feedback": []
        },
        {
            "title": "The Persistence of Memory",
            "artist": "Salvador Dalí",
            "year": 1931,
            "medium": "Oil on canvas",
            "image_url": "https://img.etsystatic.com/il/61d9e8/1269147028/il_fullxfull.1269147028_p8c3.jpg",
            "description": "A surreal painting by Salvador Dalí.",
            "feedback": []
        }
    ]
    if ARTWORKS_COLLECTION.count_documents({}) == 0:
        ARTWORKS_COLLECTION.insert_many(artworks)
        print("Seed data inserted.")

seed_data()

# Helper Functions
def get_artwork_by_id(artwork_id):
    artwork = ARTWORKS_COLLECTION.find_one({"_id": ObjectId(artwork_id)})
    if artwork:
        return artwork
    else:
        raise NotFound("Artwork not found")

def paginate_artworks(page, per_page=5):
    total_count = ARTWORKS_COLLECTION.count_documents({})
    artworks = list(ARTWORKS_COLLECTION.find().skip((page - 1) * per_page).limit(per_page))
    total_pages = (total_count + per_page - 1) // per_page
    return artworks, total_pages

# Forms
class ArtworkForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    artist = StringField('Artist', validators=[DataRequired()])
    year = IntegerField('Year', validators=[DataRequired(), NumberRange(min=0)])
    medium = StringField('Medium')
    description = TextAreaField('Description')
    image_url = URLField('Image URL', validators=[URL()])
    submit = SubmitField('Submit')

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/artworks', methods=['GET'])
def get_artworks():
    try:
        page = int(request.args.get('page', 1))
        artworks, total_pages = paginate_artworks(page)
        return render_template('artworks.html', artworks=artworks, page=page, total_pages=total_pages)
    except Exception as e:
        flash(f"Error fetching artworks: {str(e)}", 'danger')
        return redirect(url_for('index'))

@app.route('/artworks/new', methods=['GET', 'POST'])
def new_artwork():
    form = ArtworkForm()
    if form.validate_on_submit():
        try:
            new_artwork = {
                "title": form.title.data,
                "artist": form.artist.data,
                "year": form.year.data,
                "medium": form.medium.data,
                "image_url": form.image_url.data,
                "description": form.description.data,
                "feedback": []
            }
            ARTWORKS_COLLECTION.insert_one(new_artwork)
            flash("New artwork created successfully!", 'success')
            return redirect(url_for('get_artworks'))
        except Exception as e:
            flash(f"Error creating artwork: {str(e)}", 'danger')
    return render_template('new_artwork.html', form=form)

@app.route('/artworks/<artwork_id>', methods=['GET', 'POST'])
def artwork_detail(artwork_id):
    try:
        artwork = get_artwork_by_id(artwork_id)
    except NotFound as e:
        flash(str(e), 'warning')
        return redirect(url_for('get_artworks'))

    if request.method == 'POST':
        feedback = request.form.get('feedback')
        if feedback:
            ARTWORKS_COLLECTION.update_one({"_id": ObjectId(artwork_id)}, {"$push": {"feedback": feedback}})
            flash("Feedback added successfully!", 'success')
        else:
            flash("Feedback cannot be empty.", 'warning')
        return redirect(url_for('artwork_detail', artwork_id=artwork_id))

    return render_template('artwork_detail.html', artwork=artwork)

@app.route('/artworks/edit/<artwork_id>', methods=['GET', 'POST'])
def edit_artwork(artwork_id):
    try:
        artwork = get_artwork_by_id(artwork_id)
    except NotFound as e:
        flash(str(e), 'warning')
        return redirect(url_for('get_artworks'))

    form = ArtworkForm(obj=artwork)
    if form.validate_on_submit():
        try:
            updated_artwork = {
                "title": form.title.data,
                "artist": form.artist.data,
                "year": form.year.data,
                "medium": form.medium.data,
                "description": form.description.data,
                "image_url": form.image_url.data
            }
            ARTWORKS_COLLECTION.update_one({"_id": ObjectId(artwork_id)}, {"$set": updated_artwork})
            flash("Artwork updated successfully!", 'success')
            return redirect(url_for('get_artworks'))
        except Exception as e:
            flash(f"Error updating artwork: {str(e)}", 'danger')

    return render_template('edit_artwork.html', form=form, artwork=artwork)

@app.route('/artworks/delete/<artwork_id>', methods=['POST'])
def delete_artwork(artwork_id):
    try:
        result = ARTWORKS_COLLECTION.delete_one({"_id": ObjectId(artwork_id)})
        if result.deleted_count:
            flash("Artwork deleted successfully!", 'success')
        else:
            flash("Artwork not found.", 'warning')
    except Exception as e:
        flash(f"Error deleting artwork: {str(e)}", 'danger')
    return redirect(url_for('get_artworks'))

@app.route('/search', methods=['GET'])
def search_artworks():
    query = request.args.get('q', '').lower()  # Get the search query and convert it to lowercase
    try:
        # Perform a simple in-memory text search by checking if the query is in any of the artwork fields
        artworks = list(ARTWORKS_COLLECTION.find())
        filtered_artworks = [
            artwork for artwork in artworks
            if query in artwork['title'].lower()
            or query in artwork['artist'].lower()
            or query in artwork['description'].lower()
        ]
        return render_template('artworks.html', artworks=filtered_artworks)
    except Exception as e:
        flash(f"Error searching artworks: {str(e)}")
        return redirect(url_for('get_artworks'))

if __name__ == '__main__':
    app.run(debug=True)
